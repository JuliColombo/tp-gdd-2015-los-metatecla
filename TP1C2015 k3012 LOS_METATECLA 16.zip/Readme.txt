Curso:K3012

Numero Grupo: 16

Integrantes:
 	-Colombo, Julieta (147.155-7)
	-Damilano Maison, Sandro (147.046-2)
	-Kaynar, Eduardo Martin (146.475-9)
	-Petrilli, Matias (147.205-7)

Email: julietanataliacolombo@yahoo.com.ar