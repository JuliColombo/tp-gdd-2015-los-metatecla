﻿namespace PagoElectronico.ABM_Rol
{
    partial class ModificarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.funcionalidadesActuales = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbfuncionalidades = new System.Windows.Forms.Label();
            this.lbestado = new System.Windows.Forms.Label();
            this.nombreRol = new System.Windows.Forms.Label();
            this.grpNuevosDatos = new System.Windows.Forms.GroupBox();
            this.chkEstado = new System.Windows.Forms.CheckBox();
            this.textNewNombre = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.funcionalidadesDelSistema = new System.Windows.Forms.CheckedListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.botonGuardar = new System.Windows.Forms.Button();
            this.botonCancelar = new System.Windows.Forms.Button();
            this.botonNuevaFunc = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.grpNuevosDatos.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.funcionalidadesActuales);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lbfuncionalidades);
            this.groupBox1.Controls.Add(this.lbestado);
            this.groupBox1.Controls.Add(this.nombreRol);
            this.groupBox1.Location = new System.Drawing.Point(14, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(223, 249);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos Actuales";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "label2";
            // 
            // funcionalidadesActuales
            // 
            this.funcionalidadesActuales.FormattingEnabled = true;
            this.funcionalidadesActuales.Location = new System.Drawing.Point(20, 88);
            this.funcionalidadesActuales.Name = "funcionalidadesActuales";
            this.funcionalidadesActuales.Size = new System.Drawing.Size(183, 147);
            this.funcionalidadesActuales.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "label1";
            // 
            // lbfuncionalidades
            // 
            this.lbfuncionalidades.AutoSize = true;
            this.lbfuncionalidades.Location = new System.Drawing.Point(17, 72);
            this.lbfuncionalidades.Name = "lbfuncionalidades";
            this.lbfuncionalidades.Size = new System.Drawing.Size(87, 13);
            this.lbfuncionalidades.TabIndex = 1;
            this.lbfuncionalidades.Text = "Funcionalidades:";
            // 
            // lbestado
            // 
            this.lbestado.AutoSize = true;
            this.lbestado.Location = new System.Drawing.Point(17, 47);
            this.lbestado.Name = "lbestado";
            this.lbestado.Size = new System.Drawing.Size(43, 13);
            this.lbestado.TabIndex = 1;
            this.lbestado.Text = "Estado:";
            // 
            // nombreRol
            // 
            this.nombreRol.AutoSize = true;
            this.nombreRol.Location = new System.Drawing.Point(17, 25);
            this.nombreRol.Name = "nombreRol";
            this.nombreRol.Size = new System.Drawing.Size(47, 13);
            this.nombreRol.TabIndex = 0;
            this.nombreRol.Text = "Nombre:";
            // 
            // grpNuevosDatos
            // 
            this.grpNuevosDatos.Controls.Add(this.chkEstado);
            this.grpNuevosDatos.Controls.Add(this.textNewNombre);
            this.grpNuevosDatos.Controls.Add(this.label6);
            this.grpNuevosDatos.Controls.Add(this.funcionalidadesDelSistema);
            this.grpNuevosDatos.Controls.Add(this.label5);
            this.grpNuevosDatos.Controls.Add(this.label4);
            this.grpNuevosDatos.Controls.Add(this.label3);
            this.grpNuevosDatos.Location = new System.Drawing.Point(252, 9);
            this.grpNuevosDatos.Name = "grpNuevosDatos";
            this.grpNuevosDatos.Size = new System.Drawing.Size(289, 248);
            this.grpNuevosDatos.TabIndex = 1;
            this.grpNuevosDatos.TabStop = false;
            this.grpNuevosDatos.Text = "Nuevos Datos";
            // 
            // chkEstado
            // 
            this.chkEstado.AutoSize = true;
            this.chkEstado.Location = new System.Drawing.Point(78, 47);
            this.chkEstado.Name = "chkEstado";
            this.chkEstado.Size = new System.Drawing.Size(73, 17);
            this.chkEstado.TabIndex = 6;
            this.chkEstado.Text = "Habilitado";
            this.chkEstado.UseVisualStyleBackColor = true;
            // 
            // textNewNombre
            // 
            this.textNewNombre.Location = new System.Drawing.Point(78, 22);
            this.textNewNombre.Name = "textNewNombre";
            this.textNewNombre.Size = new System.Drawing.Size(200, 20);
            this.textNewNombre.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(25, 196);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(253, 39);
            this.label6.TabIndex = 4;
            this.label6.Text = "Aviso: Las funcionalidades seleccionadas seran \r\nreemplazadas por las existentes " +
                "( Es decir que si\r\nse quiere mantener una funcionalidad se debe tildar)";
            // 
            // funcionalidadesDelSistema
            // 
            this.funcionalidadesDelSistema.FormattingEnabled = true;
            this.funcionalidadesDelSistema.Location = new System.Drawing.Point(28, 99);
            this.funcionalidadesDelSistema.Name = "funcionalidadesDelSistema";
            this.funcionalidadesDelSistema.Size = new System.Drawing.Size(250, 94);
            this.funcionalidadesDelSistema.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Funcionalidades:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Estado:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Nombre:";
            // 
            // botonGuardar
            // 
            this.botonGuardar.Location = new System.Drawing.Point(358, 265);
            this.botonGuardar.Name = "botonGuardar";
            this.botonGuardar.Size = new System.Drawing.Size(84, 23);
            this.botonGuardar.TabIndex = 2;
            this.botonGuardar.Text = "Guardar";
            this.botonGuardar.UseVisualStyleBackColor = true;
            this.botonGuardar.Click += new System.EventHandler(this.botonGuardar_Click);
            // 
            // botonCancelar
            // 
            this.botonCancelar.Location = new System.Drawing.Point(448, 265);
            this.botonCancelar.Name = "botonCancelar";
            this.botonCancelar.Size = new System.Drawing.Size(93, 23);
            this.botonCancelar.TabIndex = 3;
            this.botonCancelar.Text = "Cancelar";
            this.botonCancelar.UseVisualStyleBackColor = true;
            this.botonCancelar.Click += new System.EventHandler(this.botonCancelar_Click);
            // 
            // botonNuevaFunc
            // 
            this.botonNuevaFunc.Location = new System.Drawing.Point(236, 265);
            this.botonNuevaFunc.Name = "botonNuevaFunc";
            this.botonNuevaFunc.Size = new System.Drawing.Size(116, 23);
            this.botonNuevaFunc.TabIndex = 4;
            this.botonNuevaFunc.Text = "Nueva Funcionalidad";
            this.botonNuevaFunc.UseVisualStyleBackColor = true;
            this.botonNuevaFunc.Click += new System.EventHandler(this.botonNuevaFunc_Click);
            // 
            // ModificarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 300);
            this.Controls.Add(this.botonNuevaFunc);
            this.Controls.Add(this.botonCancelar);
            this.Controls.Add(this.botonGuardar);
            this.Controls.Add(this.grpNuevosDatos);
            this.Controls.Add(this.groupBox1);
            this.Name = "ModificarForm";
            this.Text = "Modificar Rol";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpNuevosDatos.ResumeLayout(false);
            this.grpNuevosDatos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox funcionalidadesActuales;
        private System.Windows.Forms.Label lbfuncionalidades;
        private System.Windows.Forms.Label lbestado;
        private System.Windows.Forms.Label nombreRol;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpNuevosDatos;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckedListBox funcionalidadesDelSistema;
        private System.Windows.Forms.Button botonGuardar;
        private System.Windows.Forms.Button botonCancelar;
        private System.Windows.Forms.CheckBox chkEstado;
        private System.Windows.Forms.TextBox textNewNombre;
        private System.Windows.Forms.Button botonNuevaFunc;
    }
}