﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PagoElectronico.Listados
{
    class CliListado
    {
        public string nombre { get; set; }
        public string apellido { get; set; }
        public string documento { get; set; }
        public int cantidad { get; set; }
    }
}
