﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PagoElectronico.ABM_Cliente
{
    public partial class AltaClienteExitoForm : Form
    {
        public AltaClienteExitoForm()
        {
            InitializeComponent();
        }

        private void AltaClienteExitoForm_Load(object sender, EventArgs e)
        {

        }
    }
}
