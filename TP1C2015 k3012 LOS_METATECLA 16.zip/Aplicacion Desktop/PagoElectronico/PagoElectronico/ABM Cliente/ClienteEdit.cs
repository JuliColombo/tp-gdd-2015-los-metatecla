﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PagoElectronico.ABM_Cliente
{
    class ClienteEdit
    {
        public String nombre { get; set; }
        public String apellido { get; set; }
        public String tipo_doc { get; set; }
        public int documento { get; set; }
        public String mail { get; set; }
        public int id { get; set; }
    }
}
