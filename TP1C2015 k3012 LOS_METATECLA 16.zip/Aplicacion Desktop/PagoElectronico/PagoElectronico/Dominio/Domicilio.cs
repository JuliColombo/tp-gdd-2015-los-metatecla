﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PagoElectronico.Dominio
{
    class Domicilio
    {
        public String calle { get; set; }
        public int numero { get; set; }
        public int piso { get; set; }
        public String depto { get; set; }

    }
}
